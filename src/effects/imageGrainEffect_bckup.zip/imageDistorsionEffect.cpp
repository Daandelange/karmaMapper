//
//  imageDistorsionEffect.cpp
//  karmaMapper
//
//  Created by Daan de Lange on 12/3/14.
//
//  - - - -
//
//  Parent class for all effects.
//  Implements some standard methods for overall usage.
//

// todo:
// implement some shape-serving functions such as getShapesbyVertexNumber(), getShapesByType, getRandomShapes(int _nb), getShapesByGroup(int _group_id), etc.
// this will probably be problematic: http://stackoverflow.com/questions/3488571/does-insertion-of-elements-in-a-vector-damages-a-pointer-to-the-vector

#include "imageDistorsionEffect.h"

// - - - - - - -
// CONSTRUCTORS
// - - - - - - -

imageDistorsionEffect::imageDistorsionEffect(){
	
	reset();
	
	// effect type must match with class
	effectType = "imageDistorsionEffect";
}

imageDistorsionEffect::~imageDistorsionEffect(){
	
}

// - - - - - - -
// GLOBAL EFFECT FUNCTIONS
// - - - - - - -

// initialises the effect
// This function is called before it starts rendering.
// Rendering without having called this function should not be possible.
// isReady() should return true after this is done. (can take a long time)
bool imageDistorsionEffect::initialise(){
	isLoading = false;
	
	img.load("effects/imageDistorsionEffect/black_mamba.jpg");
	
	basicEffect::initialise();
}

// todo: update -(handled by)-> animation
// returns true if rendering succeeded
bool imageDistorsionEffect::render(){
	if( !isReady() ) return false;
	
	// draw bounding box
	//ofSetColor( 255,0,0 );
	//ofNoFill();
	//if(overallBoundingBox.width > 0) ofDrawRectangle( overallBoundingBox );
	
	/*for(int i=0; i<shapes.size(); i++){
		shapes[i]->render();
	}*/
	
	//musicEffect::renderVariables();
	
	
	
	for(int i=0; i<items.size(); i++){
		items[i].render( img.getPixels() );
	}
	
	
	return true;
}

// like ofApp::update()
void imageDistorsionEffect::update(){
	basicEffect::update();
	
	if( items.size() < 20 && ofRandom(0,5)>3 ) items.push_back(imageDistorsionItem(*shapes[round(ofRandom(0, shapes.size()))]->getPositionPtr()));
	
	for(int i=items.size()-1; i>=0; i--){
		if(items[i].isDead){
			items.erase(items.begin() + 1);
		}
		
		items[i].update();
	}
}

// resets all values
void imageDistorsionEffect::reset(){
	basicEffect::reset();
	
	
	items.resize(0);
}

// - - - - - - -
// CONTROLLER FUNCTIONS
// - - - - - - -

bool imageDistorsionEffect::randomizePresets(){
	return true;
}



// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
// imageDistrosionItem
// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
imageDistorsionItem::imageDistorsionItem(){
	imageDistorsionItem( ofPoint(0,0) );
}

imageDistorsionItem::imageDistorsionItem(ofPoint _position){
	position = _position;
	isDead = false;
}

imageDistorsionItem::~imageDistorsionItem(){
	
}

void imageDistorsionItem::render( const ofPixels& _pix){
	int radius = karmaSoundAnalyser::getInstance().getZeroCrossings()/200;
	
	for(int x=position.x-radius; x<position.x+radius; x+=round(ofRandom(1,radius/10)) ){
		if( x < 0 || x > _pix.getWidth() ) continue;
		
		for(int y=position.y-radius; y<position.y+radius; y+=round(ofRandom(1,radius/10))){
			if( y < 0 || y > _pix.getHeight() ) continue;
			
			int offset = y*_pix.getWidth() + x;
			ofSetColor( (ofColor) _pix[offset] );
			ofDrawCircle(x, y, 1);
		}
	}
	
}

void imageDistorsionItem::update(){
	position += ofVec2f( karmaSoundAnalyser::getInstance().getBalance(true)*10.f, karmaSoundAnalyser::getInstance().getSpectrumVariation()/1000.f )*karmaSoundAnalyser::getInstance().getVolumeMono()*2;
	
	if( position.x < 0 || position.x > ofGetWidth() || position.y < 0 || position.y > ofGetHeight() ) isDead = true;
}
