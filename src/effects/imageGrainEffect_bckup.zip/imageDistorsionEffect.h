//
//  imageDistorsionEffect.h
//  karmaMapper
//
//  Created by Daan de Lange on 12/3/14.
//
//
//

#pragma once

#include "ofMain.h"
#include "basicShape.h"
#include "musicEffect.h"

// forward declaration;
class imageDistorsionItem;

class imageDistorsionEffect : public musicEffect {
	
public:
	// constructors
	imageDistorsionEffect();
	virtual ~imageDistorsionEffect();
	
	// global effect functions
	virtual bool initialise();
	virtual bool render();
	virtual void update();
	virtual void reset();
	
	// controller functions
	virtual bool randomizePresets();

	
	
protected:
	
	
private:
	vector<imageDistorsionItem> items;
	ofImage img;
};

class imageDistorsionItem {
public:
	imageDistorsionItem();
	imageDistorsionItem(ofPoint _position);
	~imageDistorsionItem();
	
	void update();
	void render( const ofPixels& _pix);
	
	ofPoint position;
	bool isDead;
	vector<ofPoint> distorsions;
};